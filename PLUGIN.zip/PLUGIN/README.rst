A metadata plugin for isbnlib_ using the **dummy** service.

After install, a new metadata provider (``dummy``) is available in ``isbnlib``.



.. _isbnlib https://pypi.python.org/pypi/isbnlib

