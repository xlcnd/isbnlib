# -*- coding: utf-8 -*-


def myformatter(canonical):
    """My fanstatic code for a new formatter :) ."""
    return str(canonical)
