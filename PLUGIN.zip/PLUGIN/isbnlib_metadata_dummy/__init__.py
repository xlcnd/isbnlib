from _dummy import query    # <- adapt that
