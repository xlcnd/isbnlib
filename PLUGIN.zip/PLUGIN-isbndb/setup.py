# -*- coding: utf-8 -*-

"""isbnlib-isbndb -- an isbnlib plugin for the ISBNdb.com service."""


from setuptools import setup


setup(
    name='isbnlib-isbndb',
    version='0.0.1',
    author='__________________________',
    author_email='______________________________',
    url='_____________________________________',
    download_url='___________________________________',
    packages=['isbnlib_isbndb/'],
    entry_points = {
        'isbnlib.metadata': ['isbndb=isbnlib_isbndb:query']
    },
    install_requires=["isbnlib>=3.9.1,<3.11.0"],
    license='LGPL v3',
    description='An isbnlib plugin for the ISBNdb.com service.',
    keywords='ISBN, isbnlib, ISBNdb',
    classifiers=[
        'Programming Language :: Python',
        'Programming Language :: Python :: 2',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'License :: OSI Approved :: GNU Lesser General Public License v3 (LGPLv3)',
        'Operating System :: OS Independent',
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Intended Audience :: End Users/Desktop',
        'Environment :: Console',
        'Topic :: Text Processing :: General',
        'Topic :: Software Development :: Libraries :: Python Modules',
    ],
)
