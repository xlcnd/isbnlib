A metadata plugin for isbnlib_ using the **isbndb.com** service (**an api key is needed**, you could get it here_).

To install, from the command line, enter (in some cases you have to precede the command with ``sudo``):

.. code-block:: bash

    $ pip install isbnlib-isbndb


After install, a new metadata provider (``isbndb``) is available in ``isbnlib``.

> **IMPORTANT**
> You have to register the apikey in ``config`` by calling
> ``config.add_apikey('isbndb', <yourapikey>)``
> **BEFORE** you use ``query(isbn)``!



.. _isbnlib https://pypi.python.org/pypi/isbnlib

.. _here: http://isbndb.com/api/v3/docs

