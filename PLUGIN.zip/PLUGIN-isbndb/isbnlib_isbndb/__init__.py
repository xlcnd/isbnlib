from ._isbndb import query

__version__ = '0.0.1'

__plugin_author__ = 'xxx'
__plugin_description__ = 'Metadata for books from isbndb.com'
__plugin_homepage__ = 'github.com/xxx/isbnlib-isbndb'
__plugin_service_language__ = 'en'
__plugin_service_name__ = 'isbndb'
__plugin_type__ = 'metadata'
