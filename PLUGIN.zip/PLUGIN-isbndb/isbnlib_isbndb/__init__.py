from ._isbndb import query

__version__ = '0.0.1'

__plugin_main_language__ = 'en'
__plugin_service_name__  = 'isbndb'
__plugin_type__          = 'metadata'
